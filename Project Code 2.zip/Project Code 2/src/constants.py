# CST8334 - Software Project
# Student: Franklin Mwanga, Li Shun, Yinghua Song, Qingfang Tan, Qian Tang
# Group 16

# Screen dimension
WIDTH = 1480
HEIGHT = 760
# Bottom row cards
BOTTOMROW_XY = (200, 200)
# Top row cards
TOPROW_Y = 25
# Card dimension
CARD_DIM = (98, 140)
# Spacing between cards
# CARD_SPACING = 20
CARD_SPACING = 50
# Different card suits
CARD_SUITS = ["HEARTS", "DIAMONDS", "CLUBS", "SPADES"]
# Vertical offset of bottom row holders
CARD_HOLDER_VER_OFFSET = 25
# Small item on card size
#CARD_SMALL_ITEM_SIZE = (18, 21)
CARD_SMALL_ITEM_SIZE = (21, 21)
CARD_NUMBER_SIZE = (21, 25) #modify the size by qf

MOUSEHOLDER_OFFSET = (0, CARD_HOLDER_VER_OFFSET)
TOPLEFTHOLDER_OFFSET = (30, 0)
TOPRIGHTHOLDER_OFFSET = (0, 0)
BOTTOMROWHOLDER_OFFSET = (0, CARD_HOLDER_VER_OFFSET)

# restart button
#RESTART_BUTTON_SIZE = (50, 50)
RESTART_BUTTON_SIZE = (80, 80)